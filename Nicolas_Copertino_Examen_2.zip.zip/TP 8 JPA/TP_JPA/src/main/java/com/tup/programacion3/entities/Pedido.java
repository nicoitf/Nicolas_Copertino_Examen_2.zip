package com.tup.programacion3.entities;

import com.tup.programacion3.enums.Estado;
import com.tup.programacion3.enums.FormaPago;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true, of = "id")
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pedidos")
public class Pedido extends Base implements Calculable {

    private LocalDate fecha;

    private Estado estado;

    @Builder.Default
    private Double total = 0.0;

    private FormaPago formaPago;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @OneToMany(
            mappedBy = "pedido",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @Builder.Default
    private Set<DetallePedido> detallesPedido = new HashSet<>();

    public void addDetallePedido(int cantidad, Producto producto) {

        Double subtotal = cantidad * producto.getPrecio();

        DetallePedido detalle = DetallePedido.builder()
                .cantidad(cantidad)
                .subtotal(subtotal)
                .producto(producto)
                .pedido(this)
                .build();

        detallesPedido.add(detalle);

        calcularTotal();
    }

    public DetallePedido findDetallePedidoByProducto(Producto producto) {

        for (DetallePedido detalle : detallesPedido) {

            if (detalle.getProducto().equals(producto)) {
                return detalle;
            }
        }

        return null;
    }

    public void deleteDetallePedidoByProducto(Producto producto) {

        DetallePedido detalle = findDetallePedidoByProducto(producto);

        if (detalle != null) {
            detallesPedido.remove(detalle);
            calcularTotal();
        }
    }

    @Override
    public void calcularTotal() {

        this.total = detallesPedido.stream()
                .mapToDouble(DetallePedido::getSubtotal)
                .sum();
    }

    public int cantidadItems() {

        return detallesPedido.stream()
                .mapToInt(DetallePedido::getCantidad)
                .sum();
    }
}