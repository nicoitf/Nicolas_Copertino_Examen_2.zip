package com.tup.programacion3.entities;

import com.tup.programacion3.enums.Rol;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.CascadeType;
import jakarta.persistence.OneToMany;

@Getter
@Setter
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true, of = "mail")
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "usuarios")
public class Usuario extends Base {

    private String nombre;

    private String apellido;

    private String mail;

    private String celular;

    private String contrasenia;

    private Rol rol;

    @OneToMany(
            mappedBy = "usuario",
            cascade = CascadeType.ALL
    )
    @Builder.Default
    private Set<Pedido> pedidos = new HashSet<>();
}