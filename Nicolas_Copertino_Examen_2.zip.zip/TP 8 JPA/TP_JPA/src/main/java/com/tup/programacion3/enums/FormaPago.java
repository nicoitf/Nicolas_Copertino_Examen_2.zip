package com.tup.programacion3.enums;

public enum FormaPago {
    EFECTIVO,
    TARJETA_DEBITO,
    TARJETA_CREDITO,
    TRANSFERENCIA
}