package com.tup.programacion3;

import com.tup.programacion3.entities.Categoria;
import com.tup.programacion3.entities.Producto;
import com.tup.programacion3.repository.CategoriaRepository;
import com.tup.programacion3.repository.ProductoRepository;
import com.tup.programacion3.util.JPAUtil;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final CategoriaRepository categoriaRepo = new CategoriaRepository();
    private static final ProductoRepository productoRepo = new ProductoRepository();

    public static void main(String[] args) {

        int opcion;

        do {
            System.out.println("\n===== MENU PRINCIPAL =====");
            System.out.println("1. Categorias");
            System.out.println("2. Productos");
            System.out.println("3. Reportes");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 -> menuCategorias();
                case 2 -> menuProductos();
                case 3 -> menuReportes();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);

        JPAUtil.close();
    }

    private static void menuCategorias() {

        int opcion;

        do {
            System.out.println("\n===== MENU CATEGORIAS =====");
            System.out.println("1. Alta categoria");
            System.out.println("2. Baja logica categoria");
            System.out.println("3. Modificar categoria");
            System.out.println("4. Listar categorias");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 -> altaCategoria();
                case 2 -> bajaCategoria();
                case 3 -> modificarCategoria();
                case 4 -> listarCategorias();
                case 0 -> System.out.println("Volviendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);
    }

    private static void menuProductos() {

        int opcion;

        do {
            System.out.println("\n===== MENU PRODUCTOS =====");
            System.out.println("1. Alta producto");
            System.out.println("2. Baja logica producto");
            System.out.println("3. Modificar producto");
            System.out.println("4. Listar productos");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 -> altaProducto();
                case 2 -> bajaProducto();
                case 3 -> modificarProducto();
                case 4 -> listarProductos();
                case 0 -> System.out.println("Volviendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);
    }

    private static void menuReportes() {

        int opcion;

        do {
            System.out.println("\n===== MENU REPORTES =====");
            System.out.println("1. Productos por categoria");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opcion: ");

            opcion = leerEntero();

            switch (opcion) {
                case 1 -> productosPorCategoria();
                case 0 -> System.out.println("Volviendo...");
                default -> System.out.println("Opcion invalida.");
            }

        } while (opcion != 0);
    }

    private static void altaCategoria() {

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        if (nombre.isBlank()) {
            System.out.println("Error: el nombre no puede estar vacio.");
            return;
        }

        System.out.print("Descripcion: ");
        String descripcion = scanner.nextLine();

        Categoria categoria = Categoria.builder()
                .nombre(nombre)
                .descripcion(descripcion)
                .build();

        categoria = categoriaRepo.guardar(categoria);

        System.out.println("Categoria guardada con ID: " + categoria.getId());
    }

    private static void bajaCategoria() {

        listarCategorias();

        System.out.print("Ingrese ID de la categoria a eliminar: ");
        Long id = leerLong();

        Optional<Categoria> categoriaOptional = categoriaRepo.buscarPorId(id);

        if (categoriaOptional.isEmpty() || categoriaOptional.get().isEliminado()) {
            System.out.println("Error: categoria inexistente o ya dada de baja.");
            return;
        }

        Categoria categoria = categoriaOptional.get();
        categoriaRepo.eliminarLogico(id);

        System.out.println("Categoria dada de baja: " + categoria.getNombre());
    }

    private static void modificarCategoria() {

        listarCategorias();

        System.out.print("Ingrese ID de la categoria a modificar: ");
        Long id = leerLong();

        Optional<Categoria> categoriaOptional = categoriaRepo.buscarPorId(id);

        if (categoriaOptional.isEmpty() || categoriaOptional.get().isEliminado()) {
            System.out.println("Error: categoria inexistente o dada de baja.");
            return;
        }

        Categoria categoria = categoriaOptional.get();

        System.out.println("Nombre actual: " + categoria.getNombre());
        System.out.print("Nuevo nombre (enter para conservar): ");
        String nuevoNombre = scanner.nextLine();

        if (!nuevoNombre.isBlank()) {
            categoria.setNombre(nuevoNombre);
        }

        System.out.println("Descripcion actual: " + categoria.getDescripcion());
        System.out.print("Nueva descripcion (enter para conservar): ");
        String nuevaDescripcion = scanner.nextLine();

        if (!nuevaDescripcion.isBlank()) {
            categoria.setDescripcion(nuevaDescripcion);
        }

        categoriaRepo.guardar(categoria);

        System.out.println("Categoria modificada correctamente.");
    }

    private static void listarCategorias() {

        List<Categoria> categorias = categoriaRepo.listarActivos();

        System.out.println("\n===== CATEGORIAS ACTIVAS =====");

        if (categorias.isEmpty()) {
            System.out.println("No hay categorias activas.");
            return;
        }

        for (Categoria categoria : categorias) {
            System.out.println(
                    "ID: " + categoria.getId()
                            + " | Nombre: " + categoria.getNombre()
                            + " | Descripcion: " + categoria.getDescripcion()
            );
        }
    }

    private static void altaProducto() {

        List<Categoria> categorias = categoriaRepo.listarActivos();

        if (categorias.isEmpty()) {
            System.out.println("No hay categorias activas. No se puede crear el producto.");
            return;
        }

        listarCategorias();

        System.out.print("Ingrese ID de la categoria: ");
        Long categoriaId = leerLong();

        Optional<Categoria> categoriaOptional = categoriaRepo.buscarPorId(categoriaId);

        if (categoriaOptional.isEmpty() || categoriaOptional.get().isEliminado()) {
            System.out.println("Error: categoria invalida.");
            return;
        }

        Categoria categoria = categoriaOptional.get();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        if (nombre.isBlank()) {
            System.out.println("Error: el nombre no puede estar vacio.");
            return;
        }

        System.out.print("Descripcion: ");
        String descripcion = scanner.nextLine();

        System.out.print("Precio: ");
        Double precio = leerDouble();

        if (precio <= 0) {
            System.out.println("Error: el precio debe ser mayor a 0.");
            return;
        }

        System.out.print("Stock: ");
        int stock = leerEntero();

        if (stock < 0) {
            System.out.println("Error: el stock no puede ser negativo.");
            return;
        }

        Producto producto = Producto.builder()
                .nombre(nombre)
                .descripcion(descripcion)
                .precio(precio)
                .stock(stock)
                .imagen("")
                .disponible(true)
                .categoria(categoria)
                .build();

        producto = productoRepo.guardar(producto);

        System.out.println("Producto guardado con ID: " + producto.getId());
        System.out.println("Categoria asignada: " + categoria.getNombre());
    }

    private static void bajaProducto() {

        listarProductos();

        System.out.print("Ingrese ID del producto a eliminar: ");
        Long id = leerLong();

        Optional<Producto> productoOptional = productoRepo.buscarPorId(id);

        if (productoOptional.isEmpty() || productoOptional.get().isEliminado()) {
            System.out.println("Error: producto inexistente o ya dado de baja.");
            return;
        }

        Producto producto = productoOptional.get();
        productoRepo.eliminarLogico(id);

        System.out.println("Producto dado de baja: " + producto.getNombre());
    }

    private static void modificarProducto() {

        listarProductos();

        System.out.print("Ingrese ID del producto a modificar: ");
        Long id = leerLong();

        Optional<Producto> productoOptional = productoRepo.buscarPorId(id);

        if (productoOptional.isEmpty() || productoOptional.get().isEliminado()) {
            System.out.println("Error: producto inexistente o dado de baja.");
            return;
        }

        Producto producto = productoOptional.get();

        System.out.println("Nombre actual: " + producto.getNombre());
        System.out.print("Nuevo nombre (enter para conservar): ");
        String nuevoNombre = scanner.nextLine();

        if (!nuevoNombre.isBlank()) {
            producto.setNombre(nuevoNombre);
        }

        System.out.println("Precio actual: " + producto.getPrecio());
        System.out.print("Nuevo precio (enter para conservar): ");
        String nuevoPrecioTexto = scanner.nextLine();

        if (!nuevoPrecioTexto.isBlank()) {
            Double nuevoPrecio = Double.parseDouble(nuevoPrecioTexto);

            if (nuevoPrecio <= 0) {
                System.out.println("Error: el precio debe ser mayor a 0.");
                return;
            }

            producto.setPrecio(nuevoPrecio);
        }

        System.out.println("Stock actual: " + producto.getStock());
        System.out.print("Nuevo stock (enter para conservar): ");
        String nuevoStockTexto = scanner.nextLine();

        if (!nuevoStockTexto.isBlank()) {
            int nuevoStock = Integer.parseInt(nuevoStockTexto);

            if (nuevoStock < 0) {
                System.out.println("Error: el stock no puede ser negativo.");
                return;
            }

            producto.setStock(nuevoStock);
        }

        productoRepo.guardar(producto);

        System.out.println("Producto modificado correctamente.");
    }

    private static void listarProductos() {

        List<Producto> productos = productoRepo.listarActivos();

        System.out.println("\n===== PRODUCTOS ACTIVOS =====");

        if (productos.isEmpty()) {
            System.out.println("No hay productos activos.");
            return;
        }

        for (Producto producto : productos) {
            System.out.println(
                    "ID: " + producto.getId()
                            + " | Nombre: " + producto.getNombre()
                            + " | Precio: " + producto.getPrecio()
                            + " | Stock: " + producto.getStock()
                            + " | Categoria: " + producto.getCategoria().getNombre()
            );
        }
    }

    private static void productosPorCategoria() {

        listarCategorias();

        System.out.print("Ingrese ID de la categoria: ");
        Long categoriaId = leerLong();

        List<Producto> productos = productoRepo.buscarPorCategoria(categoriaId);

        System.out.println("\n===== PRODUCTOS POR CATEGORIA =====");

        if (productos.isEmpty()) {
            System.out.println("No hay productos activos en esa categoria.");
            return;
        }

        for (Producto producto : productos) {
            System.out.println(
                    "ID: " + producto.getId()
                            + " | Nombre: " + producto.getNombre()
                            + " | Precio: " + producto.getPrecio()
                            + " | Stock: " + producto.getStock()
            );
        }
    }

    private static int leerEntero() {
        int valor = scanner.nextInt();
        scanner.nextLine();
        return valor;
    }

    private static Long leerLong() {
        Long valor = scanner.nextLong();
        scanner.nextLine();
        return valor;
    }

    private static Double leerDouble() {
        Double valor = scanner.nextDouble();
        scanner.nextLine();
        return valor;
    }
}