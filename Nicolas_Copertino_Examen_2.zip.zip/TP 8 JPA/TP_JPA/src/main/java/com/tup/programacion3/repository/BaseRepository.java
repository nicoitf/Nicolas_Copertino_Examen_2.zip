package com.tup.programacion3.repository;

import com.tup.programacion3.entities.Base;
import com.tup.programacion3.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.List;
import java.util.Optional;

public abstract class BaseRepository<T extends Base> {

    protected final EntityManagerFactory emf;
    protected final Class<T> entityClass;

    public BaseRepository(Class<T> entityClass) {
        this.emf = JPAUtil.getEntityManagerFactory();
        this.entityClass = entityClass;
    }

    public T guardar(T entity) {

        EntityManager em = emf.createEntityManager();

        try {

            em.getTransaction().begin();

            T entidadGuardada = em.merge(entity);

            em.getTransaction().commit();

            return entidadGuardada;

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            throw e;

        } finally {
            em.close();
        }
    }

    public Optional<T> buscarPorId(Long id) {

        EntityManager em = emf.createEntityManager();

        try {

            T entidad = em.find(entityClass, id);

            return Optional.ofNullable(entidad);

        } finally {
            em.close();
        }
    }

    public List<T> listarActivos() {

        EntityManager em = emf.createEntityManager();

        try {

            String jpql =
                    "SELECT e FROM "
                            + entityClass.getSimpleName()
                            + " e WHERE e.eliminado = false";

            return em.createQuery(jpql, entityClass)
                    .getResultList();

        } finally {
            em.close();
        }
    }

    public boolean eliminarLogico(Long id) {

        EntityManager em = emf.createEntityManager();

        try {

            T entidad = em.find(entityClass, id);

            if (entidad == null) {
                return false;
            }

            em.getTransaction().begin();

            entidad.setEliminado(true);

            em.merge(entidad);

            em.getTransaction().commit();

            return true;

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }

            throw e;

        } finally {
            em.close();
        }
    }
}